import login from './login';
import index from './index';
export {
    login,
    index
}