- 相应框架或技术栈的快速启动
github 项目  Starter  克隆 git clone     npm install
 .git 删除

- 组件， 路由接管一切   yarn add vue-router vuex axios
 最好用目录
 了解 <router-view/> 全局启用的结果
  install ?
- 全家桶
  vue 实战能力 就是 全家桶
  vue-router 路由
  vuex   数据流管理
  axios  API
  components下的组件构成页面的子元素

 -  alias  短路径 路径名
    短路径 常用的

 - 目录架构
    - components 组件
    - pages 页面级别组件
    - commons header , footer,
    dialog 等跨页面的通用组件
    - element-ui 框架级别组件
        全局可用了
- 在components pages 目录下面加一个 index.js 模块化输出所有的文件，
   可读性

- transition name
   v-enter(短)->v-enter-active(1s) 
   Enter
   v-leave ->v-leave-active Leave               yarn add less less-loader
   npm install vue-axios
